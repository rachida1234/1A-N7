#include <unistd.h>  /*Importation des bibliotheques nécessaires*/
#include <string.h>    
#include <stdbool.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>    /* opérations sur les fichiers */
#include <signal.h>  /*pour la gestion des signaux*/
#include <sys/stat.h>
#include <sys/wait.h> 
#include <stdio.h>
#include "readcmd.h" /*permet de manipuler une ligne de commande.*/

struct cmdline *cmd; /*La ligne de commande*/
int nbCommandes=0; /*Nombre de sequences dans une commande*/

enum Status {
     ACTIF_FG, SUSPENDU, ACTIF_BG /*Les status d'un processus*/
};
typedef enum Status T_Status;

typedef struct {
       int id;/*Identifiant du processus propre au minishell*/
       pid_t pid;
       char *ligneCmd; /*La ligne de commande lancée*/
       T_Status status; /*fait réference au statut du job*/
} Job;

typedef struct {
        int nb; /*nb maximal des id*/ 
        int K; /*nombre de fils crées*/
        Job list[];      
} listJobs;

/*Pid du processus en avant-plan */
pid_t pid_fg;
/*Déclaration de listeJobs*/
listJobs listeJobs;

/**********************Fonctions qui permettent la gestion de la liste des jobs********************/

/* la commande 'lj' permet de lister tous les processus lancés depuis le shell*/
void lj() {
    if (listeJobs.K >= 1) {
       for (int j =0; j< listeJobs.K; j++) {
            if (listeJobs.list[j].status == ACTIF_FG){
                printf("[%d]     pid: %d     Actif(FG)     %s \n" ,listeJobs.list[j].id ,listeJobs.list[j].pid, listeJobs.list[j].ligneCmd);
                fflush(stdout);
            
            } else if (listeJobs.list[j].status == ACTIF_BG){
                printf("[%d]     pid: %d     Actif(BG)    %s \n" ,listeJobs.list[j].id ,listeJobs.list[j].pid, listeJobs.list[j].ligneCmd);
                fflush(stdout);
            } else {
                printf("[%d]     pid: %d     Suspendu     %s \n" ,listeJobs.list[j].id ,listeJobs.list[j].pid, listeJobs.list[j].ligneCmd);
                fflush(stdout);
            }
        }
    }
}
/*Chercher le max des ids*/
int Max(){
  int max=listeJobs.list[0].id;
  for (int j=1; j< listeJobs.K; j++) {
        if (listeJobs.list[j].id > max) {
            max=listeJobs.list[j].id;
        }
        }
    return max;
}

/*Supprimer un job de liste jobs*/
void deleteJob(pid_t pid_fg){
 int start = getIndice(pid_fg);
    if (start != -1) {
        for (int i= start; i<= listeJobs.K; i++) {
            listeJobs.list[i] = listeJobs.list[i + 1];
        }
        listeJobs.K--;
        listeJobs.nb = Max();
   }
}

/*Ajouter un nouveau job à listeJobs*/
void addJob(int fils, char* commande, T_Status status) {
    listeJobs.list[listeJobs.K].pid = fils;
    listeJobs.list[listeJobs.K].id = listeJobs.nb +1;
    
    char *ligne_commande = malloc(20*sizeof(char));
    strcpy(ligne_commande, commande);
    listeJobs.list[listeJobs.K].ligneCmd = ligne_commande;
    listeJobs.list[listeJobs.K].status = status;
    listeJobs.nb =Max();
    listeJobs.K++ ;
}

/*retourner le pid d'un Job dans listJobs à partir de son id*/
int getPid(int id) {
    for (int j=0; j< listeJobs.K; j++) {
        if (listeJobs.list[j].id == id) {
            return listeJobs.list[j].pid;   
        }
    }
    return -1;
}
/*retourner l'indice d'un Job dans listJobs à partir de son pid*/
int getIndice(pid_t Pid) {
    for (int j=0; j<= listeJobs.K; j++) {
        if (listeJobs.list[j].pid == Pid) {
            return j;   
        }
    }
    return -1;
}
/* la commande 'stop' permet de suspendre un job */
void stop ( char ** cmd) {
    /*Si l'id fourni à sj n'est pas valide*/
    if ((getPid(atoi(cmd[1])) == -1)| (atoi(cmd[1]) >listeJobs.nb)){
          printf("stop : identifiant fourni inexistant \n");
    } else if (cmd[1]==0){
        printf("utilisation : stop [identifiant du processus >=1] .\n");
    } else {
        int pid = getPid(atoi(cmd[1]));
        kill(pid, SIGSTOP);
        listeJobs.list[getIndice(pid)].status = SUSPENDU;
    }
}

/* la commande 'bg' permet de reprendre en arrière plan un job suspendu*/
void BG ( char ** cmd) {
    /*Si l'id fourni à BG n'existe pas*/
    if ((getPid(atoi(cmd[1])) == -1)| (atoi(cmd[1]) >listeJobs.nb)){
          printf("identifiant fourni inexistant! \n");
          
    } else if (cmd[1]==0) {/*la commande 'bg' n'est pas suivi de l'id du Job*/
          printf("utilisation : bg [identifiant du processus >=1] .\n");
    } else {
        /*reprendre le processus en arrière plan*/
        int pid = getPid(atoi(cmd[1]));
        kill(pid, SIGCONT);
        listeJobs.list[getIndice(pid)].status = ACTIF_BG;
    }
}

/* la commande 'fg' permet de poursuivre en avant plan un job suspendu ou en arrière plan*/
void FG ( char ** cmd) {
    /*Si l'id fourni à FG n'existe pas*/
     if ((getPid(atoi(cmd[1])) == -1)| (atoi(cmd[1]) >listeJobs.nb)){
          printf("identifiant fourni inexistant ! \n");
          
    } else if (cmd[1]==0) {/*la commande 'fg' n'est pas suivi de l'id du Job*/
          printf("utilisation : fg [identifiant du processus >=1] .\n");
    } else {
        int pid = getPid(atoi(cmd[1]));
        int i=getIndice(pid);
        listeJobs.list[i].status = ACTIF_FG;
        printf("%s \n",listeJobs.list[i].ligneCmd);
        kill(pid, SIGCONT);
        waitpid (pid , 0, 0);
        deleteJob(pid);
    }
}

/*Traitant du signal SIGCHLD */
void handlerSIGCHLD(int signal) { 
     int status_fils;
     pid_t pid_fils;
     do {
        pid_fils = waitpid(-1, &status_fils, WNOHANG | WUNTRACED | WCONTINUED);
        if ((pid_fils == -1)) {
            perror("Erreur de waitpid");
            exit(EXIT_FAILURE);
        } else if (pid_fils > 0) {
           int a=getIndice(pid_fils);
            if (a!=-1) {
                if (WIFSTOPPED(status_fils)) {
                   listeJobs.list[a].status = SUSPENDU;
                } else if (WIFEXITED(status_fils)) {
                   deleteJob(pid_fils);
                } else if (WIFCONTINUED(status_fils)) {
                   listeJobs.list[a].status = ACTIF_FG;
                } 
            }
        }
   } while (pid_fils > 0);
}

/*Traitant du signal SIGINT (ctrl-c)*/
void handlerSIGINT(int signal) {    
     kill(SIGKILL, pid_fg);
     deleteJob(pid_fg);
     printf("\n");
}
/*Traitement de pipes*/
void traitementPipe(int pipe_cmd1[2], int pipe_cmd2[2], int nbPipe) {
	nbPipe +=1;
	/*on créé un tube s'il y a une commande de plus*/
	if (nbPipe < nbCommandes) {
		pipe(pipe_cmd2);
	}
    pid_t fils=fork();
    if (nbPipe < nbCommandes && fils ==0) {
		/*fermer le tube ayant servie à l'étape précédente*/
		close(pipe_cmd1[0]);
		close(pipe_cmd1[1]);
        /*creer un nouveau tube*/
		int pipe_cmd3[2];
		/*faire un appel récursif*/
		traitementPipe(pipe_cmd2,pipe_cmd3,nbPipe);
	}
	/*pere qui est donc le fils du précédent*/
	else if (fils!=0) {
		close(pipe_cmd1[0]);
		dup2(pipe_cmd1[1],1);
		close(pipe_cmd1[1]);
		if (nbPipe < nbCommandes){
			close(pipe_cmd2[1]);
			dup2(pipe_cmd2[0],0);
		}
		execvp(cmd->seq[nbCommandes-nbPipe][0],cmd->seq[nbCommandes-nbPipe]);
	}
}


/***********************************************************************************************/
/********************************************Main***********************************************/
int main(int argc, char *argv[]) {
    char cwd[200];
    int wstatus;
    while(1) {                 
         do {
            getcwd(cwd,sizeof(cwd)); /*Récuperer le nom du répértoire du travail courant*/
            printf("\n ~/%s$",cwd);
            cmd=readcmd();
            signal(SIGINT, handlerSIGINT);
            signal(SIGTSTP,SIG_IGN);
            } while(cmd->seq[0] == NULL);
            /*La commande interne "exit"*/
            if (!strcmp(cmd->seq[0][0], "exit")) {
                    exit(1);
                }
            /*La commande interne "cd"*/
            else if (!strcmp(cmd->seq[0][0],"cd")) {
                    if (cmd->seq[0][1]==NULL) {
                            chdir(getenv("HOME"));
                    } else if (!strcmp(cmd->seq[0][1],"~")) {
                            chdir(getenv("HOME"));
                    } else if (cmd->seq[0][2]!=NULL) {
                            printf("cd: too many arguments");
                    } else if (chdir(cmd->seq[0][1])<0) {
                        printf("cd : %s : No such file or directory.\n", cmd->seq[0][1]);
                    } else {
                        /*si chdir(cmd->seq[0][1])==0 (file or directory exists)*/
                        chdir(cmd->seq[0][1]);
                    }
                }
            /*La commande lancée est  'bg id' */
            else if (!strcmp(cmd->seq[0][0], "bg")) {
                    BG(cmd->seq[0]);
            }
            /*La commande lancée est 'fg id' */
            else if (!strcmp(cmd->seq[0][0], "fg")) {
                    FG(cmd->seq[0]);
            }
            /* La commande lancée est 'stop id'*/ 
            else if (!strcmp(cmd->seq[0][0], "sj")) {
                    stop(cmd->seq[0]);
            }
            /* La commande lancée est 'lj'*/ 
            else if (!strcmp(cmd->seq[0][0], "lj")) {
                    lj();
            }
            
            else if (cmd->seq[1] == NULL) {
            int fils = fork();
            /*Fils*/
            if (fils == 0) {
                /*Lancer les commandes non internes*/
                 if (cmd->in!=NULL && cmd->out!=NULL) {
                    int is=open(cmd->in,O_RDONLY);
                    int id=open(cmd->out,O_CREAT|O_WRONLY|O_TRUNC,S_IRWXU);
                    /*traiter systématiquement les retours d'erreur des appels */
                    if (is < 0) {
                        printf("Erreur ouverture %s\n", cmd->in) ;
                        exit(1);
                        }
                    if (id < 0) {
                        printf("Erreur ouverture %s\n", cmd->out);
                        exit(1);
                    }
                    int dupis=dup2(is,0); /*f1 associé à l'entrée standard de commande*/
                    if (dupis == -1) {   /* échec du dup2 */
                        printf("Erreur dup2\n");
                        exit(5);
                    }
                    close(is);
                    int dupid=dup2(id,1); /*f2 associé à la sortie standard de la commande*/
                    if (dupid == -1) {   /* échec du dup2 */
                        printf("Erreur dup2\n");
                        exit(5);
                    }
                    close(id);
                    execlp(cmd->seq[0][0],cmd->seq[0][0],cmd->seq[0][1],NULL);
                } else if(cmd->in!=NULL && cmd->out==NULL) {/*redirection de l'entrée standard*/
                    int id=open(cmd->in,O_RDONLY);
                    /*traiter systématiquement les retours d'erreur des appels */
                    if (id < 0) {
                        printf("Erreur ouverture %s\n", cmd->in);
                        exit(1);
                    }
                    int dupid=dup2(id,0);
                    if (dupid == -1) {   /* échec du dup2 */
                        printf("Erreur dup2\n") ;
                        exit(5) ;
                    }
                    close(id);
                    execlp(cmd->seq[0][0],cmd->seq[0][0],cmd->in,NULL);
                } else if (cmd->in==NULL && cmd->out!=NULL){ /*redirection de la sortie standard vers le fichier*/
                        int id=open(cmd->out,O_CREAT|O_WRONLY|O_TRUNC,S_IRWXU);
                        /*traiter systématiquement les retours d'erreur des appels */
                        if (id < 0) {
                            printf("Erreur ouverture %s\n", cmd->out);
                            exit(1) ;
                        }
                        int dupid=dup2(id,1);
                        if (dupid == -1) {   /* échec du dup2 */
                          printf("Erreur dup2\n") ;
                          exit(5) ;
                    }
                        close(id);
                        execlp(cmd->seq[0][0],cmd->seq[0][0],cmd->seq[0][1],NULL);
                } else if (cmd->in==NULL && cmd->out==NULL){
                     execvp(cmd->seq[0][0],cmd->seq[0]);
                } else {
                    perror("Command not found");
                    exit(EXIT_FAILURE);
                }

            } else if (fils ==-1) {
                printf("Fork error\n");
                exit(1);
            } else { /*Père*/
                    if (cmd->backgrounded == NULL){
                            /* Enregistrement du processus fils dans listeJobs*/
                            addJob(fils, *cmd->seq[0], ACTIF_FG);
                            pid_fg = fils;
                            waitpid(fils,&wstatus,WUNTRACED);
                            /*supprimer le processus car son traitement est achevé.*/
                            deleteJob(fils);
                           
                    } else {
                            /* Enregistrement du processus fils dans listeJobs*/
                            addJob(fils, *cmd->seq[0], ACTIF_BG);
                    }
            }
                
            } else {
                int pipe_cmd1[2]  ; 
                pipe(pipe_cmd1);
                int Fils1=fork();
                if (Fils1 ==-1) {
                    printf("Erreur fork \n");
                    exit(1);
                }
                if (Fils1 == 0) {
                    int pipe_cmd2[2];
                    int nbPipe=0;
                    traitementPipe(pipe_cmd1,pipe_cmd2,nbPipe);
                } else {
					close (pipe_cmd1[1]); //fermer la sortie
        			dup2 (pipe_cmd1[0], 0);
        			close (pipe_cmd1[0]);
					execvp(cmd->seq[nbCommandes][0],cmd->seq[nbCommandes]);
				}

                        
                            
}
}
}



