#include <stdio.h> /* entr  ́e es / sorties */
#include <unistd.h> /* primitives de base : fork , ...*/
#include <stdlib.h> /* exit */
# define MAX_PAUSES 10 /* nombre d ’ attentes maximum */
#include <signal.h> 

void handler (int num_sig)
{
   printf("Reception du signal recu : %d \n", num_sig);
   
}
int main ( int argc , char * argv []) {
sigset_t s;
sigemptyset(&s);

signal(SIGUSR1, handler) ;
signal(SIGUSR2, handler) ;
sigaddset(&s,SIGINT);
sigaddset(&s,SIGUSR1);
sigprocmask(SIG_BLOCK,&s,NULL);

sleep(10);
kill(getpid(),SIGUSR1); //un seul reste en pending
kill(getpid(),SIGUSR1);
sleep(5);

kill(getpid(),SIGUSR2);
kill(getpid(),SIGUSR2);

sigdelset(&s,SIGINT);
sigprocmask(SIG_UNBLOCK,&s,NULL);

sleep(10);
sigaddset(&s,SIGINT);
sigdelset(&s,SIGUSR1);
sigprocmask(SIG_UNBLOCK,&s,NULL);

printf("salut!");

return EXIT_SUCCESS;
}






